Рабочий материал, не участвует в работе сайта.

- `*.txt` — текст, выгруженный из PDF Google-форм (`pdftotext -layout`)
- `parse.py` — превращает этот текст в черновой JSON теста
- `*.draft.json` — промежуточный результат разбора

Как добавить новый тест:
1. Открыть Google-форму → Печать → Сохранить как PDF
2. `pdftotext -layout форма.pdf _src/g5-math.txt`
3. `python3 _src/parse.py _src/g5-math.txt`
4. Перенести вопросы в `tests/5-matematika.json`, добавить шапку (grade, subject, minutes)
5. Проставить `correct` и обновить `tests/manifest.json`
