#!/usr/bin/env python3
"""Вырезает формулы из PDF, свёрстанных в Word.

Здесь формулы — не картинки, а текст со смещением (дроби, степени, корни).
Поэтому ищем внутри вопроса строки, сдвинутые вправо от левого поля, и
вырезаем занимаемую ими полосу страницы как PNG.
"""
import re, sys, json, pathlib
import pdfplumber

OPT = re.compile(r'^\s*[A-EА-ЕВСД]\s*[).](\s|$)')
QNUM = re.compile(r'^\s*(\d{1,2})\s*[.)]\s*\S')
DPI = 200


def blocks(pdf):
    """Разбивает документ на вопросы: [{n, lines:[(page, line)]}]"""
    rows = []
    for pi, page in enumerate(pdf.pages):
        for l in page.extract_text_lines() or []:
            rows.append((pi, l))
    left = min(l['x0'] for _, l in rows)
    qs, cur = [], None
    for pi, l in rows:
        m = QNUM.match(l['text'])
        if m and l['x0'] < left + 12 and not OPT.match(l['text']):
            cur = {'n': int(m.group(1)), 'lines': []}
            qs.append(cur)
        if cur is not None:
            cur['lines'].append((pi, l))
    return qs, left


def crop(pdf_path, out_dir, tag):
    out_dir = pathlib.Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    made = {}
    with pdfplumber.open(pdf_path) as pdf:
        qs, left = blocks(pdf)
        for q in qs:
            # строка вопроса заканчивается там, где начинаются варианты
            body = []
            for pi, l in q['lines']:
                if OPT.match(l['text']):
                    break
                body.append((pi, l))
            # формула — строки, заметно сдвинутые вправо от левого поля
            shifted = [(pi, l) for pi, l in body if l['x0'] > left + 25]
            if not shifted:
                continue
            by_page = {}
            for pi, l in shifted:
                by_page.setdefault(pi, []).append(l)
            for k, (pi, ls) in enumerate(sorted(by_page.items())):
                page = pdf.pages[pi]
                top = min(l['top'] for l in ls) - 4
                bot = max(l['bottom'] for l in ls) + 4
                # не залезать на строку обычного текста над формулой
                above = [l['bottom'] for p2, l in body
                         if p2 == pi and l['x0'] <= left + 25 and l['bottom'] <= top + 6]
                if above:
                    top = max(top, max(above) + 1)
                if bot - top < 10:
                    continue
                box = (left - 4, max(0, top), page.width - 40, min(page.height, bot))
                name = f"{tag}-q{q['n']:02d}" + (f"-{k+1}" if len(by_page) > 1 else "") + ".png"
                page.crop(box).to_image(resolution=DPI).save(str(out_dir / name))
                made.setdefault(q['n'], []).append('images/' + name)
    return made


if __name__ == '__main__':
    pdf_path, tag = sys.argv[1], sys.argv[2]
    res = crop(pdf_path, '/home/claude/zerdeli-tests/tests/images', tag)
    print(tag, '→', json.dumps({k: len(v) for k, v in sorted(res.items())}, ensure_ascii=False))
