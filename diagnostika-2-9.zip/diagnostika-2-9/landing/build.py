#!/usr/bin/env python3
"""Собирает лендинг диагностики из одного исходника diagnostika-body.html.

Исходник — цельная страница: стили, разметка и скрипт в одном файле, так его
удобно править и смотреть. Отсюда получается три вещи:

  landing.css / landing.js     — раздаются через jsDelivr, лежат в репозитории
  build/landing-embed.html     — то, что вставляется в Webflow: только разметка
                                 плюс три ссылки. Меньше 12 КБ и больше не меняется:
                                 правки лендинга уезжают на сайт обычным git push.
  build/preview-ru|kz.html     — готовые страницы целиком, чтобы посмотреть локально

    python3 landing/build.py [базовый-адрес]
"""
import re, sys, json, pathlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = ROOT / 'build'
src = (HERE / 'diagnostika-body.html').read_text(encoding='utf-8')

META = {
    'ru': dict(
        lang='ru',
        title='Онлайн-диагностика знаний школьника 2–9 класс в Алматы | Zerdeli',
        desc='Онлайн-тест по школьной программе, отчёт с картой пробелов по темам и разбор '
             'с педагогом на Гагарина 93. Комплект по классу: от математики до химии и английского.',
        other='/diagnostika-znaniy-kz'),
    'kz': dict(
        lang='kk',
        title='Оқушының білімін онлайн диагностикалау 2–9 сынып, Алматы | Zerdeli',
        desc='Мектеп бағдарламасы бойынша онлайн тест, тақырыптар бойынша олқылықтар картасы '
             'және Гагарин 93-те мұғаліммен талдау. Сынып бойынша толық жинақ.',
        other='/diagnostika-znaniy'),
}

TPL = """<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="description" content="{desc}">
<meta name="theme-color" content="#ACDF08">
<title>{title}</title>
<link rel="alternate" hreflang="{alt_lang}" href="{other}">
{head}
</head>
<body>
{body}
</body>
</html>
"""


def split():
    """Делит исходник на стили, разметку и скрипт."""
    i = src.index('<header class="hdr">')
    head, body = src[:i], src[i:]
    style = re.search(r'<style>(.*?)</style>', head, re.S)
    rest_head = re.sub(r'<style>.*?</style>', '', head, flags=re.S).strip()
    script = re.search(r'<script>(.*)</script>\s*$', body, re.S)
    markup = body[:script.start()].strip() if script else body.strip()
    return style.group(1).strip(), rest_head, markup, script.group(1).strip()


BASE = 'https://nursultannewvibe.github.io/zerdeli-diagnostika/diagnostika-2-9/'


def build(base=BASE):
    css, rest_head, markup, js = split()
    cdn = (base if base.endswith('/') else base + '/') + 'landing/'
    OUT.mkdir(exist_ok=True)

    note = ('/* Собрано из landing/diagnostika-body.html скриптом landing/build.py.\n'
            '   Правится там, не здесь: этот файл перезаписывается при каждой сборке. */\n')
    (HERE / 'landing.css').write_text(note + css + '\n', encoding='utf-8')

    # спрайт с иконкой WhatsApp лежит в «голове», а <use href="#wa-ic"> — в разметке
    sprite = re.search(r'<svg width="0".*?</svg>', rest_head, re.S)
    full_markup = (sprite.group(0) + '\n' if sprite else '') + markup

    # Разметку кладём в скрипт, а не в Webflow. Тексты всё равно подставляются скриптом
    # (в разметке только пустые data-t), так что в Webflow от неё не было пользы —
    # зато теперь и разметка правится в репозитории и уезжает на сайт через git push.
    inject = (note
              + 'var ZD_HOST = document.getElementById("zd-landing") || document.body;\n'
              + 'ZD_HOST.innerHTML = ' + json.dumps(full_markup, ensure_ascii=False) + ';\n\n')
    (HERE / 'landing.js').write_text(inject + js + '\n', encoding='utf-8')

    fonts = re.search(r'<link rel="stylesheet" href="(https://fonts\.googleapis[^"]+)"', rest_head)
    embed = (f'<!-- Лендинг диагностики Zerdeli.\n'
             f'     Разметка, стили и скрипт лежат в репозитории zerdeli-diagnostika,\n'
             f'     папка diagnostika-2-9/landing, и раздаются через GitHub Pages.\n'
             f'     Правятся в diagnostika-body.html и уезжают на сайт обычным\n'
             f'     git push — здесь менять нечего. -->\n'
             + (f'<link rel="stylesheet" href="{fonts.group(1)}">\n' if fonts else '')
             + f'<link rel="stylesheet" href="{cdn}landing.css">\n'
             + '<div id="zd-landing"></div>\n'
             + f'<script src="{cdn}landing.js"></script>')
    (OUT / 'landing-embed.html').write_text(embed, encoding='utf-8')

    for code, meta in META.items():
        page = TPL.format(head=rest_head + '\n<style>\n' + css + '\n</style>',
                          body=full_markup + '\n<script>\n' + js + '\n</script>',
                          alt_lang='kk' if code == 'ru' else 'ru', **meta)
        (OUT / f'landing-{code}.html').write_text(page, encoding='utf-8')

    print(f"landing/landing.css        — {len(css):,} знаков (на CDN)")
    print(f"landing/landing.js         — {len(js):,} знаков (на CDN)")
    print(f"build/landing-embed.html   — {len(embed):,} знаков (это вставляем в Webflow)")
    print(f"build/landing-ru.html, build/landing-kz.html — целые страницы для просмотра")
    print(f"адрес файлов: {cdn}")


if __name__ == '__main__':
    build(*(sys.argv[1:] or []))
