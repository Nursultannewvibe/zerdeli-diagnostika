/* Собрано из landing/diagnostika-body.html скриптом landing/build.py.
   Правится там, не здесь: этот файл перезаписывается при каждой сборке. */
var ZD_HOST = document.getElementById("zd-landing") || document.body;
ZD_HOST.innerHTML = "<svg width=\"0\" height=\"0\" style=\"position:absolute\" aria-hidden=\"true\"><symbol id=\"wa-ic\" viewBox=\"0 0 24 24\"><path d=\"M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm0 18.15h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.25-8.23 2.2 0 4.27.86 5.83 2.42a8.19 8.19 0 0 1 2.41 5.82c0 4.54-3.7 8.23-8.24 8.23Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.24-.64.8-.79.97-.14.16-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.43.13-.15.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.42l-.47-.01c-.16 0-.43.06-.65.31-.22.25-.85.83-.85 2.03 0 1.2.87 2.35.99 2.51.12.16 1.71 2.61 4.14 3.66.58.25 1.03.4 1.38.51.58.19 1.11.16 1.53.1.47-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.11-.22-.17-.47-.29Z\"/></symbol></svg>\n<header class=\"hdr\">\n  <div class=\"wrap hdr-in\">\n    <a class=\"brand\" href=\"#top\">ZERDELI<span>.</span></a>\n    <div class=\"hdr-right\">\n      <a class=\"hdr-phone\" href=\"tel:+77780403999\">+7 778 040 3999</a>\n      <div class=\"langs\" role=\"group\" aria-label=\"Тіл / Язык\">\n        <button type=\"button\" data-lang=\"kz\" aria-pressed=\"false\">KZ</button>\n        <button type=\"button\" data-lang=\"ru\" aria-pressed=\"true\">RU</button>\n      </div>\n    </div>\n  </div>\n</header>\n\n<main id=\"top\">\n\n  <!-- ============ HERO ============ -->\n  <section class=\"hero\">\n    <div class=\"wrap hero-grid\">\n      <div class=\"hero-copy\">\n        <span class=\"eyebrow\" data-t=\"heroEyebrow\"></span>\n        <h1 data-t=\"heroH1\"></h1>\n        <p class=\"lead\" data-t=\"heroLead\"></p>\n        <div class=\"hero-cta\">\n          <a class=\"btn btn-primary\" href=\"#zayavka\" data-t=\"ctaMain\"></a>\n          <a class=\"btn btn-wa\" href=\"https://wa.me/77780403999\" target=\"_blank\" rel=\"noopener\" data-wa>\n            <svg class=\"wa-ic\" fill=\"#25D366\" aria-hidden=\"true\"><use href=\"#wa-ic\"/></svg>\n            <span data-t=\"ctaWa\"></span>\n          </a>\n        </div>\n        <div class=\"hero-facts\">\n          <span class=\"fact\" data-t=\"fact1\"></span>\n          <span class=\"fact\" data-t=\"fact2\"></span>\n          <span class=\"fact\" data-t=\"fact3\"></span>\n        </div>\n      </div>\n\n      <!-- SIGNATURE: карта пробелов -->\n      <div class=\"report\" id=\"report\">\n        <div class=\"report-top\">\n          <div>\n            <div class=\"report-title\" data-t=\"repTitle\"></div>\n            <div class=\"report-sub\" data-t=\"repSub\"></div>\n          </div>\n          <span class=\"report-tag\" data-t=\"repTag\"></span>\n        </div>\n        <div class=\"rows\" id=\"reportRows\"></div>\n        <div class=\"report-legend\">\n          <span class=\"lg\"><i class=\"dot ok\"></i><span data-t=\"legOk\"></span></span>\n          <span class=\"lg\"><i class=\"dot mid\"></i><span data-t=\"legMid\"></span></span>\n          <span class=\"lg\"><i class=\"dot gap\"></i><span data-t=\"legGap\"></span></span>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <section class=\"builder-sec\" id=\"zayavka\">\n    <div class=\"wrap\">\n      <span class=\"eyebrow\" data-t=\"bldEyebrow\"></span>\n      <h2 data-t=\"bldH2\" style=\"margin-top:12px\"></h2>\n      <p class=\"lead\" data-t=\"bldLead\" style=\"margin-top:12px\"></p>\n\n      <div class=\"builder\">\n        <form id=\"form\" novalidate>\n          <!-- шаг 1 -->\n          <div class=\"bstep\" id=\"s1\">\n            <div class=\"bstep-h\"><span class=\"bstep-n\">1</span><span class=\"bstep-t\" data-t=\"s1t\"></span></div>\n            <div id=\"grades\"></div>\n          </div>\n\n          <!-- шаг 2 -->\n          <div class=\"bstep is-off\" id=\"s2\">\n            <div class=\"bstep-h\"><span class=\"bstep-n\">2</span><span class=\"bstep-t\" data-t=\"s2t\"></span></div>\n            <div id=\"kit\" class=\"kit\"></div>\n            <p class=\"subj-hint\" id=\"subjHint\" data-t=\"s2hint\"></p>\n          </div>\n\n          <!-- шаг 3 -->\n          <div class=\"bstep is-off\" id=\"s3\">\n            <div class=\"bstep-h\"><span class=\"bstep-n\">3</span><span class=\"bstep-t\" data-t=\"s3t\"></span></div>\n\n            <div class=\"summary\" id=\"summary\" hidden>\n              <span data-t=\"sumLabel\"></span>\n              <span class=\"pill\" id=\"pillGrade\"></span>\n              <span class=\"pill\" id=\"pillCount\"></span>\n            </div>\n\n            <div class=\"form-grid\" style=\"margin-top:14px\">\n              <div class=\"field\" id=\"fName\">\n                <label for=\"name\" data-t=\"fldName\"></label>\n                <input id=\"name\" name=\"name\" type=\"text\" autocomplete=\"name\" data-ph=\"phName\">\n                <span class=\"err-msg\" data-t=\"errName\"></span>\n              </div>\n              <div class=\"field\" id=\"fPhone\">\n                <label for=\"phone\" data-t=\"fldPhone\"></label>\n                <input id=\"phone\" name=\"phone\" type=\"tel\" inputmode=\"tel\" autocomplete=\"tel\" placeholder=\"+7 (___) ___-__-__\">\n                <span class=\"err-msg\" data-t=\"errPhone\"></span>\n              </div>\n              <div class=\"field\">\n                <label for=\"when\" data-t=\"fldWhen\"></label>\n                <select id=\"when\" name=\"when\">\n                  <option value=\"asap\" data-t=\"optAsap\"></option>\n                  <option value=\"evening\" data-t=\"optEvening\"></option>\n                  <option value=\"weekend\" data-t=\"optWeekend\"></option>\n                </select>\n              </div>\n            </div>\n\n            <div class=\"form-foot\">\n              <button type=\"submit\" class=\"btn btn-primary btn-block\" id=\"submitBtn\" data-t=\"ctaSubmit\"></button>\n              <p class=\"consent\" data-t=\"consent\"></p>\n            </div>\n          </div>\n        </form>\n\n        <div class=\"done\" id=\"done\">\n          <div class=\"done-ic\"><svg viewBox=\"0 0 24 24\"><path d=\"M4 12.5 9.5 18 20 7\"/></svg></div>\n          <h3 data-t=\"doneH\"></h3>\n          <p data-t=\"doneP\"></p>\n          <!-- сюда после отправки подставляются тесты выбранного класса -->\n          <div class=\"tests\" id=\"doneTests\"></div>\n          <a class=\"btn btn-wa\" href=\"https://wa.me/77780403999\" target=\"_blank\" rel=\"noopener\">\n            <svg class=\"wa-ic\" fill=\"#25D366\" aria-hidden=\"true\"><use href=\"#wa-ic\"/></svg>\n            <span data-t=\"ctaWa\"></span>\n          </a>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <!-- ============ ЗНАКОМО ============ -->\n  <section class=\"reveal\">\n    <div class=\"wrap\">\n      <span class=\"eyebrow\" data-t=\"painEyebrow\"></span>\n      <h2 data-t=\"painH2\" style=\"margin-top:12px\"></h2>\n      <div class=\"pains\">\n        <div class=\"pain\" data-t=\"pain1\"></div>\n        <div class=\"pain\" data-t=\"pain2\"></div>\n        <div class=\"pain\" data-t=\"pain3\"></div>\n        <div class=\"pain\" data-t=\"pain4\"></div>\n      </div>\n    </div>\n  </section>\n\n  <!-- ============ КАК ПРОХОДИТ ============ -->\n  <section class=\"reveal\" style=\"padding-top:0\">\n    <div class=\"wrap\">\n      <span class=\"eyebrow\" data-t=\"howEyebrow\"></span>\n      <h2 data-t=\"howH2\" style=\"margin-top:12px\"></h2>\n      <div class=\"steps\">\n        <div class=\"step\">\n          <div class=\"step-n\">1</div>\n          <span class=\"step-when\" data-t=\"how1when\"></span>\n          <h3 data-t=\"how1h\"></h3>\n          <p data-t=\"how1p\"></p>\n        </div>\n        <div class=\"step\">\n          <div class=\"step-n\">2</div>\n          <span class=\"step-when\" data-t=\"how2when\"></span>\n          <h3 data-t=\"how2h\"></h3>\n          <p data-t=\"how2p\"></p>\n        </div>\n        <div class=\"step\">\n          <div class=\"step-n\">3</div>\n          <span class=\"step-when\" data-t=\"how3when\"></span>\n          <h3 data-t=\"how3h\"></h3>\n          <p data-t=\"how3p\"></p>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <!-- ============ ЧТО ПОЛУЧАЕТЕ ============ -->\n  <section class=\"reveal\" style=\"padding-top:0\">\n    <div class=\"wrap\">\n      <span class=\"eyebrow\" data-t=\"getEyebrow\"></span>\n      <h2 data-t=\"getH2\" style=\"margin-top:12px\"></h2>\n      <div class=\"gets\">\n        <div class=\"get\">\n          <span class=\"get-ic\"><svg viewBox=\"0 0 24 24\"><path d=\"M3 6h18M3 12h12M3 18h7\"/></svg></span>\n          <div><h3 data-t=\"get1h\"></h3><p data-t=\"get1p\"></p></div>\n        </div>\n        <div class=\"get\">\n          <span class=\"get-ic\"><svg viewBox=\"0 0 24 24\"><path d=\"M4 19V9m5 10V5m5 14v-7m5 7V8\"/></svg></span>\n          <div><h3 data-t=\"get2h\"></h3><p data-t=\"get2p\"></p></div>\n        </div>\n        <div class=\"get\">\n          <span class=\"get-ic\"><svg viewBox=\"0 0 24 24\"><path d=\"M8 3h8a2 2 0 0 1 2 2v14l-6-3-6 3V5a2 2 0 0 1 2-2Z\"/></svg></span>\n          <div><h3 data-t=\"get3h\"></h3><p data-t=\"get3p\"></p></div>\n        </div>\n        <div class=\"get\">\n          <span class=\"get-ic\"><svg viewBox=\"0 0 24 24\"><path d=\"M9 12l2 2 4-4\"/><circle cx=\"12\" cy=\"12\" r=\"9\"/></svg></span>\n          <div><h3 data-t=\"get4h\"></h3><p data-t=\"get4p\"></p></div>\n        </div>\n      </div>\n    </div>\n  </section>\n\n  <!-- ============ КОНСТРУКТОР ============ -->\n\n  <!-- ============ КАТАЛОГ ПРЕДМЕТОВ ============ -->\n  <section class=\"reveal\">\n    <div class=\"wrap\">\n      <span class=\"eyebrow\" data-t=\"catEyebrow\"></span>\n      <h2 data-t=\"catH2\" style=\"margin-top:12px\"></h2>\n      <div class=\"catalog\" id=\"catalog\"></div>\n    </div>\n  </section>\n\n  <!-- ============ PROOF ============ -->\n  <section class=\"proof\">\n    <div class=\"wrap proof-grid\">\n      <div class=\"big\">133<small data-t=\"proofBig\"></small></div>\n      <div>\n        <span class=\"eyebrow\" data-t=\"proofEyebrow\"></span>\n        <p style=\"margin-top:12px\" data-t=\"proofP\"></p>\n        <p class=\"proof-note\" data-t=\"proofNote\"></p>\n      </div>\n    </div>\n  </section>\n\n  <!-- ============ FAQ ============ -->\n  <section class=\"reveal\">\n    <div class=\"wrap\">\n      <span class=\"eyebrow\" data-t=\"faqEyebrow\"></span>\n      <h2 data-t=\"faqH2\" style=\"margin-top:12px\"></h2>\n      <div class=\"faq\" id=\"faq\"></div>\n    </div>\n  </section>\n\n  <!-- ============ FINAL ============ -->\n  <section class=\"final\">\n    <div class=\"wrap final-in\">\n      <h2 data-t=\"finH2\"></h2>\n      <div class=\"price\">\n        <span class=\"price-num\" id=\"priceNum\"></span>\n        <span class=\"price-note\" data-t=\"priceNote\"></span>\n      </div>\n      <p class=\"lead\" data-t=\"finLead\"></p>\n      <a class=\"btn btn-primary\" href=\"#zayavka\" data-t=\"ctaMain\"></a>\n    </div>\n  </section>\n\n  <!-- ============ FOOTER ============ -->\n  <footer class=\"ftr\">\n    <div class=\"wrap\">\n      <div class=\"ftr-grid\">\n        <div>\n          <h4 data-t=\"ftrWhere\"></h4>\n          <p data-t=\"ftrAddr\"></p>\n          <p style=\"margin-top:10px\"><a href=\"tel:+77780403999\">+7 778 040 3999</a></p>\n          <p><a href=\"https://wa.me/77780403999\" target=\"_blank\" rel=\"noopener\">WhatsApp</a></p>\n        </div>\n        <div>\n          <h4 data-t=\"ftrBranches\"></h4>\n          <ul>\n            <li>Бұхар Жырау 66</li>\n            <li>Сейфуллина 458</li>\n            <li>Наурызбай батыр 99/1</li>\n            <li>Розыбакиева 247</li>\n            <li>Ақсай 4</li>\n            <li>Шұғыла 350/4 к9</li>\n          </ul>\n        </div>\n        <div>\n          <h4 data-t=\"ftrNav\"></h4>\n          <ul>\n            <li><a href=\"#zayavka\" data-t=\"ftrNav1\"></a></li>\n            <li><a href=\"#top\" data-t=\"ftrNav2\"></a></li>\n          </ul>\n        </div>\n      </div>\n      <div class=\"ftr-bottom\">© <span id=\"yr\"></span> Zerdeli Education · Алматы</div>\n    </div>\n  </footer>\n</main>\n\n<div class=\"sticky\" id=\"sticky\">\n  <a class=\"btn btn-primary\" href=\"#zayavka\" data-t=\"ctaSticky\"></a>\n  <a class=\"btn btn-wa\" href=\"https://wa.me/77780403999\" target=\"_blank\" rel=\"noopener\" aria-label=\"WhatsApp\">\n    <svg class=\"wa-ic\" fill=\"#25D366\" aria-hidden=\"true\"><use href=\"#wa-ic\"/></svg>\n  </a>\n</div>";

/* ============================================================
   1. НАСТРОЙКИ — правьте здесь
   ============================================================ */
const CONFIG = {
  // язык определяется по адресу страницы: .../diagnostika-znaniy-kz → казахский
  lang: (typeof location !== 'undefined' && /-kz\/?$/.test(location.pathname)) ? 'kz' : 'ru',
  urlRu: '/diagnostika-znaniy',      // адрес русской версии
  urlKz: '/diagnostika-znaniy-kz',   // адрес казахской версии
  price: 2990,                // цена диагностики, ₸  ← УТОЧНИТЬ
  whatsapp: '77780403999',
  endpoint: '',               // сюда вставить ссылку на веб-приложение Google Apps Script
  testRu: '/test',            // страница прохождения теста
  testKz: '/test-kz',
  // манифест тестов из репозитория. Из него берутся классы и предметы:
  // так лендинг не расходится с тем, что на самом деле лежит в тестах.
  manifest: 'https://nursultannewvibe.github.io/zerdeli-diagnostika/diagnostika-2-9/tests/manifest.json'
};

/* ============================================================
   2. ПРОГРАММА ДИАГНОСТИКИ — правьте здесь
   Ключ — класс. subjects — что реально входит в комплекс.
   minutes — примерное время на весь комплекс.
   Источник: папка «Сынақ тесті Примеры» на Google Диске.
   ⚠ 9 класс — состав по аналогии с 7–8, папка была недоступна: сверить.
   ============================================================ */
const PROGRAM = {
  2: {minutes:30, subjects:[{ru:'Математика',            kz:'Математика'}]},
  3: {minutes:35, subjects:[{ru:'Математика',            kz:'Математика'}]},
  4: {minutes:45, subjects:[{ru:'Математика',            kz:'Математика'},
                            {ru:'Английский язык',       kz:'Ағылшын тілі'}]},
  5: {minutes:90, subjects:[{ru:'Математика',            kz:'Математика'},
                            {ru:'Естествознание',        kz:'Жаратылыстану'},
                            {ru:'Количественные характеристики', kz:'Сандық сипаттама'},
                            {ru:'Казахский язык',        kz:'Қазақ тілі'},
                            {ru:'Русский язык',          kz:'Орыс тілі'},
                            {ru:'Английский язык',       kz:'Ағылшын тілі'}]},
  6: {minutes:35, subjects:[{ru:'Математика',            kz:'Математика'}]},
  7: {minutes:70, subjects:[{ru:'Алгебра и геометрия',   kz:'Алгебра-геометрия'},
                            {ru:'Физика',                kz:'Физика'},
                            {ru:'Химия',                 kz:'Химия'},
                            {ru:'Английский язык',       kz:'Ағылшын тілі'}]},
  8: {minutes:70, subjects:[{ru:'Алгебра и геометрия',   kz:'Алгебра-геометрия'},
                            {ru:'Физика',                kz:'Физика'},
                            {ru:'Химия',                 kz:'Химия'},
                            {ru:'Английский язык',       kz:'Ағылшын тілі'}]},
  9: {minutes:70, subjects:[{ru:'Алгебра и геометрия',   kz:'Алгебра-геометрия'},
                            {ru:'Физика',                kz:'Физика'},
                            {ru:'Химия',                 kz:'Химия'},
                            {ru:'Английский язык',       kz:'Ағылшын тілі'}]}
};

const STAGES = [
  {id:'primary', from:2, to:4, ru:'Начальная школа', kz:'Бастауыш сынып'},
  {id:'middle',  from:5, to:6, ru:'5–6 класс',       kz:'5–6 сынып'},
  {id:'senior',  from:7, to:9, ru:'7–9 класс',       kz:'7–9 сынып'}
];

/* ============================================================
   3. ТЕКСТЫ — правьте здесь
   ============================================================ */
const T = {
ru:{
  title:'Онлайн-диагностика знаний · 2–9 класс · Zerdeli',
  heroEyebrow:'Онлайн-диагностика · 2–9 класс',
  heroH1:'Сначала диагностика — потом подготовка',
  heroLead:'Ребёнок проходит онлайн-тест дома. Вы получаете карту пробелов по темам школьной программы и приходите на разбор с педагогом — Гагарина 93.',
  ctaMain:'Выбрать класс',
  ctaSticky:'Записаться на диагностику',
  ctaWa:'Написать в WhatsApp',
  fact1:'Тест дома, онлайн',
  fact2:'Отчёт по темам, не одна оценка',
  fact3:'Вопросы на двух языках',

  repTitle:'Карта пробелов · Математика',
  repSub:'Так выглядит отчёт, который вы получаете',
  repTag:'Пример',
  legOk:'Тема усвоена',
  legMid:'Требует повторения',
  legGap:'Пробел',
  rows:[
    {n:'Числа и действия над ними',   v:85, s:'ok'},
    {n:'Периметр, площадь, объём',    v:38, s:'gap'},
    {n:'Пространственные фигуры',     v:72, s:'ok'},
    {n:'Текстовые задачи',            v:30, s:'gap'},
    {n:'Доли и дроби',                v:56, s:'mid'}
  ],

  painEyebrow:'Знакомо?',
  painH2:'Оценки есть, а понимания нет',
  pain1:'В дневнике четвёрки, а базовых тем прошлого года ребёнок не помнит.',
  pain2:'Репетитор начинает с нуля — он тоже не знает, где именно пробел.',
  pain3:'Ребёнок говорит «всё понятно», а на контрольной результат другой.',
  pain4:'Непонятно, какой предмет подтягивать в первую очередь и сколько это займёт.',

  howEyebrow:'Как проходит',
  howH2:'Три шага за одну неделю',
  how1when:'День 1 · дома',
  how1h:'Онлайн-тест',
  how1p:'Ссылка приходит в WhatsApp. Тест по программе своего класса, с телефона или компьютера. Вопросы продублированы на казахском и русском — ребёнок отвечает на удобном языке. Без оценок и сравнения с одноклассниками.',
  how2when:'День 2 · автоматически',
  how2h:'Отчёт по темам',
  how2p:'Каждый вопрос теста привязан к теме программы. Поэтому результат — не «4» и «3», а разбивка по темам: где усвоено, где нужно повторение, где настоящий пробел.',
  how3when:'День 3–5 · Гагарина 93',
  how3h:'Разбор с педагогом',
  how3p:'30 минут в центре: показываем отчёт, объясняем причины пробелов и даём план подготовки на 3 месяца. Приходить лучше вместе с ребёнком.',

  getEyebrow:'Что остаётся у вас',
  getH2:'Вы уходите с документом, а не с впечатлением',
  get1h:'Карта пробелов по темам',
  get1p:'Полный список тем программы класса с отметкой уровня по каждой.',
  get2h:'Уровень относительно программы',
  get2p:'Насколько ребёнок идёт вровень со своим классом — и по каким темам отстаёт.',
  get3h:'План на 3 месяца',
  get3p:'С какой темы начинать, в каком порядке и сколько занятий на это нужно.',
  get4h:'Рекомендация формата',
  get4p:'Группа, мини-группа или индивидуально — исходя из объёма пробелов, а не из прайса.',

  bldEyebrow:'Запись',
  bldH2:'Выберите класс — покажем, что входит',
  bldLead:'Диагностика идёт комплектом: ребёнок проходит все тесты своего класса, отчёт собирается по всем предметам сразу.',
  s1t:'Класс ребёнка',
  s2t:'Что входит в диагностику',
  s2hint:'Выберите класс — покажем состав комплекта.',
  s3t:'Контакты для записи',
  sumLabel:'Вы выбрали:',
  kitTime:'Примерно __MIN__ минут на всё',
  kitNote:'Тесты можно проходить не подряд — ребёнок делает их в удобное время в течение недели.',
  subjOne:'предмет', subjFew:'предмета', subjMany:'предметов',
  fldName:'Ваше имя',
  phName:'Как к вам обращаться',
  fldPhone:'Телефон (WhatsApp)',
  fldWhen:'Когда удобно начать',
  optAsap:'Как можно скорее',
  optEvening:'В будни после 18:00',
  optWeekend:'В выходные',
  ctaSubmit:'Записаться на диагностику',
  errName:'Напишите имя',
  errPhone:'Проверьте номер: нужно 11 цифр',
  consent:'Нажимая кнопку, вы соглашаетесь на обработку персональных данных. Мы звоним только по этой заявке.',
  doneH:'Заявка принята — можно начинать',
  doneP:'Ниже тесты Вашего класса. Проходите прямо сейчас, каждый занимает 25–90 минут. Менеджер напишет в WhatsApp и подберёт время разбора.',
  testsOne:'Открыть тест', testsSoon:'Тест готовится',
  qOne:'вопрос', qFew:'вопроса', qMany:'вопросов',
  testsNone:'Тесты для этого класса ещё готовятся — менеджер пришлёт ссылку в WhatsApp.',


  catEyebrow:'Охват',
  catH2:'Что входит по классам',
  proofEyebrow:'Результат центра',
  proofBig:'из 288 грантов НИШ по Алматы в 2026 году — у учеников Zerdeli',
  proofP:'Диагностика — тот же инструмент, с которого начинается подготовка всех наших учеников. Сначала мы находим пробелы, потом строим программу.',
  proofNote:'Большинство поступивших начали заниматься в 4–5 классе.',

  faqEyebrow:'Вопросы',
  faqH2:'Что обычно спрашивают',
  faq:[
    {q:'Диагностика платная?',           a:'Да, __PRICE__ ₸ за весь комплект. В стоимость входят все тесты класса, отчёт по темам и 30-минутный разбор с педагогом в центре.'},
    {q:'Сколько времени занимает тест?', a:'Зависит от класса: во 2–3 классе это один тест на полчаса, в 5-м — шесть предметов, около полутора часов. Проходить всё подряд не нужно — можно разбить на несколько дней.'},
    {q:'Почему нельзя выбрать один предмет?', a:'Пробел редко сидит в одном месте. Ребёнок «не тянет математику», а причина — в чтении условия задачи. Комплект по классу показывает картину целиком, поэтому план подготовки получается точнее.'},
    {q:'А если ребёнок не хочет тест?',  a:'В тесте нет оценок и сравнения с одноклассниками — результат видят только родители и педагог. Обычно это снимает напряжение.'},
    {q:'Нужно ли потом записываться на курс?', a:'Нет. Отчёт и план на 3 месяца остаются у вас в любом случае — с ними можно заниматься и самостоятельно, и с другим педагогом.'},
    {q:'На каком языке проходит тест?',  a:'Вопросы продублированы на казахском и русском в самом тесте — ребёнок читает на том языке, который ему привычнее.'},
    {q:'Где проходит разбор?',           a:'В головном филиале на Гагарина 93. Тест — онлайн из дома, очно нужно прийти только на разбор.'}
  ],

  finH2:'Записаться на диагностику',
  priceNote:'все тесты класса + отчёт по темам + разбор с педагогом',
  finLead:'Одна встреча вместо трёх месяцев занятий вслепую.',

  ftrWhere:'Разбор проходит здесь',
  ftrAddr:'Алматы, Гагарина 93 — головной филиал Zerdeli',
  ftrBranches:'Филиалы в Алматы',
  ftrNav:'Навигация',
  ftrNav1:'Записаться на диагностику',
  ftrNav2:'В начало страницы'
},
kz:{
  title:'Білім деңгейін онлайн диагностикалау · 2–9 сынып · Zerdeli',
  heroEyebrow:'Онлайн диагностика · 2–9 сынып',
  heroH1:'Алдымен диагностика жасап, сосын дайындықты бастаймыз',
  heroLead:'Бала үйде онлайн тест тапсырады. Сіз мектеп бағдарламасының тақырыптары бойынша олқылықтар картасын аласыз және Гагарин 93-тегі мұғаліммен талдауға келесіз.',
  ctaMain:'Сыныпты таңдау',
  ctaSticky:'Диагностикаға жазылу',
  ctaWa:'WhatsApp-қа жазу',
  fact1:'Тест үйде, онлайн',
  fact2:'Бір баға емес — тақырып бойынша есеп',
  fact3:'Сұрақтар екі тілде',

  repTitle:'Олқылықтар картасы · Математика',
  repSub:'Сіз алатын есеп осылай көрінеді',
  repTag:'Үлгі',
  legOk:'Тақырып меңгерілген',
  legMid:'Қайталауды қажет етеді',
  legGap:'Олқылық',
  rows:[
    {n:'Сандар және оларға амалдар қолдану',       v:85, s:'ok'},
    {n:'Периметр, аудан, көлем',                   v:38, s:'gap'},
    {n:'Кеңістіктік геометриялық фигуралар',       v:72, s:'ok'},
    {n:'Мәтінді есептер',                          v:30, s:'gap'},
    {n:'Үлестер мен бөлшектер',                    v:56, s:'mid'}
  ],

  painEyebrow:'Таныс жағдай ма?',
  painH2:'Бағасы бар, бірақ түсінігі жоқ',
  pain1:'Күнделікте бағасы жақсы, ал өткен жылдың негізгі тақырыптарын есінде сақтамаған.',
  pain2:'Репетитор нөлден бастайды — ол да олқылықтың нақты қайда екенін білмейді.',
  pain3:'Бала «бәрі түсінікті» дейді, ал бақылау жұмысында нәтиже басқаша.',
  pain4:'Қай пәнді бірінші тарту керегі және оған қанша уақыт кететіні белгісіз.',

  howEyebrow:'Қалай өтеді',
  howH2:'Бір аптада үш қадам',
  how1when:'1-күн · үйде',
  how1h:'Онлайн тест',
  how1p:'Сілтеме WhatsApp-қа келеді. Тест өз сыныбының бағдарламасы бойынша, телефоннан немесе компьютерден. Сұрақтар қазақ және орыс тілінде қатар берілген — бала өзіне ыңғайлы тілде жауап береді. Баға қойылмайды, сыныптастармен салыстырылмайды.',
  how2when:'2-күн · автоматты түрде',
  how2h:'Тақырып бойынша есеп',
  how2p:'Тесттің әр сұрағы бағдарламаның тақырыбына байланған. Сондықтан нәтиже «4» пен «3» емес, тақырып бойынша бөлінген: қайсысы меңгерілген, қайсысын қайталау керек, қайда шынайы олқылық бар.',
  how3when:'3–5-күн · Гагарин 93',
  how3h:'Мұғаліммен талдау',
  how3p:'Орталықта 30 минут: есепті көрсетеміз, олқылықтың себебін түсіндіреміз және 3 айға дайындық жоспарын береміз. Баламен бірге келген дұрыс.',

  getEyebrow:'Сізде не қалады',
  getH2:'Әсер емес, нақты құжат аласыз',
  get1h:'Тақырып бойынша олқылықтар картасы',
  get1p:'Сынып бағдарламасының толық тақырып тізімі және әрқайсысы бойынша деңгей белгісі.',
  get2h:'Бағдарламаға қатысты деңгей',
  get2p:'Бала өз сыныбымен қатар жүр ме — және қай тақырыптардан артта қалған.',
  get3h:'3 айға жоспар',
  get3p:'Қай тақырыптан бастау керек, қандай ретпен және оған қанша сабақ қажет.',
  get4h:'Формат бойынша ұсыныс',
  get4p:'Топ, шағын топ немесе жеке — прайсқа емес, олқылық көлеміне қарап ұсынамыз.',

  bldEyebrow:'Жазылу',
  bldH2:'Сыныпты таңдаңыз — құрамын көрсетеміз',
  bldLead:'Диагностика жинақ түрінде өтеді: бала өз сыныбының барлық тестін тапсырады, есеп барлық пән бойынша бірден жиналады.',
  s1t:'Баланың сыныбы',
  s2t:'Диагностика құрамы',
  s2hint:'Сыныпты таңдаңыз — жинақтың құрамын көрсетеміз.',
  s3t:'Жазылуға арналған байланыс',
  sumLabel:'Сіз таңдадыңыз:',
  kitTime:'Барлығына шамамен __MIN__ минут',
  kitNote:'Тестерді қатарынан тапсыру міндетті емес — бала оларды апта ішінде ыңғайлы уақытта орындайды.',
  subjOne:'пән', subjFew:'пән', subjMany:'пән',
  fldName:'Атыңыз',
  phName:'Сізге қалай жүгінейік',
  fldPhone:'Телефон (WhatsApp)',
  fldWhen:'Қашан бастаған ыңғайлы',
  optAsap:'Мүмкіндігінше тезірек',
  optEvening:'Жұмыс күндері 18:00-ден кейін',
  optWeekend:'Демалыс күндері',
  ctaSubmit:'Диагностикаға жазылу',
  errName:'Атыңызды жазыңыз',
  errPhone:'Нөмірді тексеріңіз: 11 сан болуы керек',
  consent:'Батырманы басу арқылы жеке деректерді өңдеуге келісім бересіз. Тек осы өтінім бойынша хабарласамыз.',
  doneH:'Өтінім қабылданды — бастауға болады',
  doneP:'Төменде сыныбыңыздың тестері. Дәл қазір тапсыруға болады, әрқайсысы 25–90 минут алады. Менеджер WhatsApp-қа жазып, талдау уақытын келіседі.',
  testsOne:'Тестті ашу', testsSoon:'Тест әзірленуде',
  qOne:'сұрақ', qFew:'сұрақ', qMany:'сұрақ',
  testsNone:'Бұл сыныпқа тестер әзірленуде — менеджер WhatsApp-қа сілтеме жібереді.',


  catEyebrow:'Қамту',
  catH2:'Сыныптар бойынша құрамы',
  proofEyebrow:'Орталық нәтижесі',
  proofBig:'2026 жылы Алматы бойынша берілген 288 НЗМ грантының — Zerdeli оқушыларында',
  proofP:'Диагностика — біздің барлық оқушыларымыздың дайындығы басталатын дәл сол құрал. Алдымен олқылықты табамыз, содан кейін бағдарлама құрамыз.',
  proofNote:'Түскендердің көбі 4–5 сыныпта оқи бастаған.',

  faqEyebrow:'Сұрақтар',
  faqH2:'Жиі сұралатыны',
  faq:[
    {q:'Диагностика ақылы ма?',              a:'Иә, толық жинақ үшін __PRICE__ ₸. Бағаға сыныптың барлық тесті, тақырып бойынша есеп және орталықта мұғаліммен 30 минуттық талдау кіреді.'},
    {q:'Тест қанша уақыт алады?',            a:'Сыныпқа байланысты: 2–3 сыныпта бұл жарты сағаттық бір тест, 5-сыныпта — алты пән, шамамен бір жарым сағат. Барлығын қатарынан тапсыру міндетті емес, бірнеше күнге бөлуге болады.'},
    {q:'Неге бір пәнді таңдауға болмайды?',  a:'Олқылық сирек бір жерде отырады. Бала «математиканы тартпайды» дейміз, ал себебі — есептің шартын оқуында. Сынып бойынша жинақ жалпы көріністі көрсетеді, сондықтан дайындық жоспары дәлірек шығады.'},
    {q:'Бала тест тапсырғысы келмесе ше?',   a:'Тестте баға қойылмайды және сыныптастармен салыстыру жоқ — нәтижені тек ата-ана мен мұғалім көреді. Әдетте бұл қысымды азайтады.'},
    {q:'Кейін курсқа жазылу міндетті ме?',   a:'Жоқ. Есеп пен 3 айлық жоспар кез келген жағдайда сізде қалады — онымен өз бетінше де, басқа мұғаліммен де жұмыс істей аласыз.'},
    {q:'Тест қай тілде өтеді?',              a:'Сұрақтар тесттің өзінде қазақ және орыс тілінде қатар берілген — бала өзіне таныс тілде оқиды.'},
    {q:'Талдау қайда өтеді?',                a:'Гагарин 93-тегі бас филиалда. Тест — үйден онлайн, орталыққа тек талдауға келу керек.'}
  ],

  finH2:'Диагностикаға жазылу',
  priceNote:'сыныптың барлық тесті + тақырып бойынша есеп + мұғаліммен талдау',
  finLead:'Үш ай көзсіз оқудың орнына — бір кездесу.',

  ftrWhere:'Талдау осында өтеді',
  ftrAddr:'Алматы, Гагарин 93 — Zerdeli бас филиалы',
  ftrBranches:'Алматыдағы филиалдар',
  ftrNav:'Навигация',
  ftrNav1:'Диагностикаға жазылу',
  ftrNav2:'Беттің басына'
}
};

/* ============================================================
   4. ЛОГИКА
   ============================================================ */
(function(){
  const $  = (s,r)=> (r||document).querySelector(s);
  const $$ = (s,r)=> Array.from((r||document).querySelectorAll(s));
  let lang = CONFIG.lang === 'kz' ? 'kz' : 'ru';
  const state = {grade:null};
  const GRADES = Object.keys(PROGRAM).map(Number).sort((a,b)=> a-b);

  const track = (name, params) => {
    try{ if(window.fbq) window.fbq('trackCustom', name, params||{}); }catch(e){}
  };

  function nf(n){ return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' '); }

  function render(){
    const t = T[lang];
    document.documentElement.lang = lang === 'kz' ? 'kk' : 'ru';
    document.title = t.title;

    $$('[data-t]').forEach(el=>{
      const v = t[el.dataset.t];
      if(typeof v === 'string') el.textContent = v;
    });
    $$('[data-ph]').forEach(el=>{ el.placeholder = t[el.dataset.ph] || ''; });
    $$('.langs button').forEach(b=> b.setAttribute('aria-pressed', String(b.dataset.lang === lang)));
    $('#priceNum').textContent = nf(CONFIG.price) + ' ₸';

    // отчёт-подпись
    $('#reportRows').innerHTML = t.rows.map(r=>`
      <div>
        <div class="row-head"><span class="row-name">${r.n}</span><span class="row-val">${r.v}%</span></div>
        <div class="track"><span class="bar ${r.s}" data-w="${r.v}"></span></div>
      </div>`).join('');
    requestAnimationFrame(()=> setTimeout(()=> $$('#reportRows .bar').forEach(b=> b.style.width = b.dataset.w + '%'), 120));

    // классы
    $('#grades').innerHTML = STAGES.map(st=>{
      const gs = GRADES.filter(g=> g >= st.from && g <= st.to);
      if(!gs.length) return '';
      return `<div class="grade-group">
        <div class="grade-label">${st[lang]}</div>
        <div class="chips">${gs.map(g=>`<button type="button" class="chip grade" data-grade="${g}" aria-pressed="${state.grade===g}">${g}</button>`).join('')}</div>
      </div>`;
    }).join('');

    renderKit();

    // каталог: карточка на каждый класс
    $('#catalog').innerHTML = GRADES.map(g=>{
      const p = PROGRAM[g];
      return `<div class="cat">
        <div><div class="cat-h">${gradeLabel(g)}</div>
        <div class="cat-g">${p.subjects.length} ${plural(p.subjects.length)} · ~${p.minutes} ${lang==='kz'?'минут':'мин'}</div></div>
        <ul>${p.subjects.map(s=>`<li>${s[lang]}</li>`).join('')}</ul>
      </div>`;
    }).join('');

    // faq
    $('#faq').innerHTML = t.faq.map((f,i)=>`
      <details${i===0?' open':''}>
        <summary>${f.q}</summary>
        <div class="ans">${f.a.replace('__PRICE__', nf(CONFIG.price))}</div>
      </details>`).join('');

    updateSummary();
  }

  function gradeLabel(g){ return lang === 'kz' ? g + '-сынып' : g + ' класс'; }

  function plural(n){
    const t = T[lang];
    if(lang === 'kz') return t.subjMany;
    const d10 = n % 10, d100 = n % 100;
    if(d10 === 1 && d100 !== 11) return t.subjOne;
    if(d10 >= 2 && d10 <= 4 && (d100 < 12 || d100 > 14)) return t.subjFew;
    return t.subjMany;
  }

  const CHECK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12.5 9.5 18 20 7"/></svg>';

  function renderKit(){
    const t = T[lang], box = $('#kit');
    if(!state.grade){ box.innerHTML = ''; $('#subjHint').hidden = false; return; }
    $('#subjHint').hidden = true;
    const p = PROGRAM[state.grade];
    box.innerHTML = `
      <div class="kit-list">${p.subjects.map(s=>`<div class="kit-item">${CHECK}<span>${s[lang]}</span></div>`).join('')}</div>
      <div class="kit-meta">
        <span class="fact"><b>${p.subjects.length}</b> ${plural(p.subjects.length)}</span>
        <span class="fact">${t.kitTime.replace('__MIN__', p.minutes)}</span>
      </div>
      <p class="kit-note">${t.kitNote}</p>`;
  }

  function updateSummary(){
    $('#s2').classList.toggle('is-off', !state.grade);
    $('#s3').classList.toggle('is-off', !state.grade);
    const sum = $('#summary');
    if(state.grade){
      const p = PROGRAM[state.grade];
      $('#pillGrade').textContent = gradeLabel(state.grade);
      $('#pillCount').textContent = p.subjects.length + ' ' + plural(p.subjects.length);
      sum.hidden = false;
    } else {
      sum.hidden = true;
    }
  }

  // выбор класса
  document.addEventListener('click', e=>{
    const g = e.target.closest('.chip.grade');
    if(!g) return;
    state.grade = Number(g.dataset.grade);
    $$('.chip.grade').forEach(c=> c.setAttribute('aria-pressed', String(Number(c.dataset.grade) === state.grade)));
    renderKit(); updateSummary();
    track('DiagGradePick', {grade: state.grade});
    setTimeout(()=> $('#name').focus({preventScroll:true}), 60);
  });

  // переключение языка
  $$('.langs button').forEach(b=>{
    b.addEventListener('click', ()=>{
      const next = b.dataset.lang;
      if(next === lang) return;
      const url = next === 'kz' ? CONFIG.urlKz : CONFIG.urlRu;
      // если казахская/русская версия лежит на отдельном URL — уходим туда,
      // иначе переключаем язык на месте (нужно для превью)
      if(url && location.pathname !== url && location.protocol.startsWith('http') && !location.host.includes('claude')){
        location.href = url + location.search + '#' + (location.hash.slice(1) || 'top');
        return;
      }
      lang = next; render();
    });
  });

  // телефон
  const phone = $('#phone');
  phone.addEventListener('input', ()=>{
    let d = phone.value.replace(/\D/g,'');
    if(d.startsWith('8')) d = '7' + d.slice(1);
    if(!d.startsWith('7')) d = '7' + d;
    d = d.slice(0,11);
    let out = '+7';
    if(d.length > 1) out += ' (' + d.slice(1,4);
    if(d.length >= 4) out += ')';
    if(d.length > 4) out += ' ' + d.slice(4,7);
    if(d.length > 7) out += '-' + d.slice(7,9);
    if(d.length > 9) out += '-' + d.slice(9,11);
    phone.value = out;
  });
  phone.addEventListener('focus', ()=>{ if(!phone.value) phone.value = '+7 ('; });

  let started = false;
  $('#form').addEventListener('input', ()=>{
    if(!started){ started = true; track('DiagFormStart', {}); }
  });

  // отправка
  /* Манифест тестов — единственный источник правды о том, какие тесты есть.
     Пока он не загрузился, работает список PROGRAM, вписанный руками.
     Как только загрузился — классы и предметы берутся из него, и лендинг
     перестаёт расходиться с содержимым репозитория. */
  let MANIFEST = null;

  async function loadManifest(){
    if(!CONFIG.manifest) return;
    try{
      const r = await fetch(CONFIG.manifest, {cache:'no-cache'});
      if(!r.ok) throw new Error(r.status);
      MANIFEST = await r.json();
    }catch(err){ console.warn('манифест тестов не загрузился, работаем по списку в коде', err); return; }

    const byGrade = {};
    MANIFEST.tests.forEach(t=>{
      (byGrade[t.grade] = byGrade[t.grade] || []).push(t);
    });
    Object.keys(byGrade).forEach(g=>{
      const list = byGrade[g];
      PROGRAM[g] = {
        minutes: list.reduce((a,t)=> a + (t.minutes || 0), 0),
        subjects: list.map(t=> ({ru: t.subject.ru, kz: t.subject.kz}))
      };
    });
    GRADES.length = 0;
    Object.keys(byGrade).map(Number).sort((a,b)=> a-b).forEach(g=> GRADES.push(g));
    if(state.grade && !GRADES.includes(state.grade)) state.grade = null;
    render();
  }

  function testsFor(grade){
    if(!MANIFEST) return null;
    return MANIFEST.tests.filter(t=> t.grade === grade);
  }

  function qPlural(n){
    const t = T[lang];
    if(lang === 'kz') return t.qMany;
    const d10 = n % 10, d100 = n % 100;
    if(d10 === 1 && d100 !== 11) return t.qOne;
    if(d10 >= 2 && d10 <= 4 && (d100 < 12 || d100 > 14)) return t.qFew;
    return t.qMany;
  }

  function renderDoneTests(){
    const t = T[lang], box = $('#doneTests');
    const list = testsFor(state.grade);
    if(!list || !list.length){
      box.innerHTML = `<p class="tests-note">${t.testsNone}</p>`;
      return;
    }
    const page = lang === 'kz' ? CONFIG.testKz : CONFIG.testRu;
    box.innerHTML = list.map((x,i)=>`
      <a href="${page}?test=${encodeURIComponent(x.id)}">
        <i>${i+1}</i>
        <span class="tt">
          <b>${x.subject[lang]}</b>
          <em>${x.questions} ${qPlural(x.questions)} · ~${x.minutes} мин${x.ready?'':' · '+t.testsSoon}</em>
        </span>
      </a>`).join('');
  }

  $('#form').addEventListener('submit', async e=>{
    e.preventDefault();
    const t = T[lang];
    const name = $('#name').value.trim();
    const digits = phone.value.replace(/\D/g,'');
    let ok = true;
    $('#fName').classList.toggle('err', name.length < 2); if(name.length < 2) ok = false;
    $('#fPhone').classList.toggle('err', digits.length !== 11); if(digits.length !== 11) ok = false;
    if(!ok || !state.grade) return;

    const p = PROGRAM[state.grade];
    const payload = {
      date: new Date().toISOString(),
      name: name,
      phone: '+' + digits,
      grade: state.grade,
      subjects: p.subjects.map(s=> s.ru).join(', '),
      when: $('#when').value,
      pageLang: lang,
      page: location.pathname || 'diagnostika',
      source: 'landing-diagnostika'
    };

    const btn = $('#submitBtn');
    btn.disabled = true; btn.style.opacity = '.6';

    try{
      if(CONFIG.endpoint){
        await fetch(CONFIG.endpoint, {
          method:'POST', mode:'no-cors',
          headers:{'Content-Type':'text/plain;charset=utf-8'},
          body: JSON.stringify(payload)
        });
      } else {
        console.log('Заявка (endpoint не настроен):', payload);
      }
    }catch(err){ console.warn(err); }

    track('DiagLead', {grade: payload.grade, subjects: payload.subjects});
    if(window.fbq) window.fbq('track','Lead');
    $('#form').style.display = 'none';
    renderDoneTests();
    $('#done').classList.add('on');
    $('#done').scrollIntoView({behavior:'smooth', block:'center'});
  });

  // липкая кнопка
  const sticky = $('#sticky'), zone = $('#zayavka');
  const io = new IntersectionObserver(es=>{
    es.forEach(en=>{
      if(en.target.id === 'zayavka') sticky.classList.toggle('on', !en.isIntersecting && window.scrollY > 400);
    });
  }, {threshold:0});
  io.observe(zone);
  window.addEventListener('scroll', ()=>{
    if(window.scrollY < 400) sticky.classList.remove('on');
  }, {passive:true});

  // reveal + скролл 50%
  const rio = new IntersectionObserver(es=>{
    es.forEach(en=>{ if(en.isIntersecting){ en.target.classList.add('in'); rio.unobserve(en.target); } });
  }, {threshold:.12});
  $$('.reveal').forEach(el=> rio.observe(el));

  let half = false;
  window.addEventListener('scroll', ()=>{
    if(half) return;
    const p = (window.scrollY + innerHeight) / document.body.scrollHeight;
    if(p > .5){ half = true; track('Scroll50', {}); }
  }, {passive:true});

  $('#yr').textContent = new Date().getFullYear();
  render();
  loadManifest();               // подтянет реальный состав тестов и перерисует
  track('DiagPageView', {lang: lang});
})();
