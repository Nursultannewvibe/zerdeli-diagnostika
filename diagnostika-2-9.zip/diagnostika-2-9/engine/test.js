/* ============================================================
   Zerdeli — движок диагностических тестов
   Вставляется одним Embed на страницу Webflow /test
   Контент тестов тянется из GitHub через jsDelivr.
   ============================================================ */
(function () {
  'use strict';

  /* ---------- 1. НАСТРОЙКИ — правьте здесь ---------- */
  var CONFIG = {
    // папка tests/ в репозитории, раздаётся через CDN.
    // после создания репы подставить: https://cdn.jsdelivr.net/gh/ПОЛЬЗОВАТЕЛЬ/zerdeli-tests@main/tests/
    base: (window.ZERDELI_TESTS_BASE || 'tests/'),
    // веб-приложение Google Apps Script, куда падают результаты
    endpoint: (window.ZERDELI_ENDPOINT || ''),
    whatsapp: '77780403999',
    landingRu: '/diagnostika-znaniy',
    landingKz: '/diagnostika-znaniy-kz'
  };

  /* ---------- 2. ТЕКСТЫ ---------- */
  var T = {
    ru: {
      pickTest: 'Выберите тест', pickHint: 'Тесты вашего класса',
      start: 'Начать тест', name: 'Имя и фамилия ученика', phone: 'Телефон родителя (WhatsApp)',
      namePh: 'Как зовут ребёнка', errName: 'Напишите имя', errPhone: 'Проверьте номер: нужно 11 цифр',
      q: 'Вопрос', of: 'из', next: 'Дальше', prev: 'Назад', finish: 'Завершить',
      pickAnswer: 'Выберите вариант ответа',
      resultTitle: 'Карта пробелов', score: 'Верных ответов',
      byTopic: 'По темам программы',
      missed: 'Где потеряны баллы', noMissed: 'Ошибок нет — все ответы верные',
      missedNote: 'Разбора по темам для этого предмета пока нет: темы к вопросам ещё не проставлены. На разборе педагог пройдёт эти вопросы вместе с ребёнком.',
      ok: 'Тема усвоена', mid: 'Требует повторения', gap: 'Пробел',
      cta: 'Записаться на разбор', ctaNote: 'Педагог объяснит причины пробелов и даст план на 3 месяца.',
      saving: 'Сохраняем результат…', saved: 'Результат сохранён',
      notReady: 'Этот тест ещё готовится', notReadyNote: 'Правильные ответы пока не заполнены — результат посчитать нельзя. Напишите нам, подберём тест вручную.',
      loadErr: 'Не удалось загрузить тест', again: 'Обновить страницу',
      resume: 'Продолжить с вопроса', restart: 'Начать заново'
    },
    kz: {
      pickTest: 'Тестті таңдаңыз', pickHint: 'Сыныбыңыздың тестері',
      start: 'Тестті бастау', name: 'Оқушының аты-жөні', phone: 'Ата-ананың телефоны (WhatsApp)',
      namePh: 'Баланың аты', errName: 'Атын жазыңыз', errPhone: 'Нөмірді тексеріңіз: 11 сан болуы керек',
      q: 'Сұрақ', of: '/', next: 'Әрі қарай', prev: 'Артқа', finish: 'Аяқтау',
      pickAnswer: 'Жауап нұсқасын таңдаңыз',
      resultTitle: 'Олқылықтар картасы', score: 'Дұрыс жауаптар',
      byTopic: 'Бағдарлама тақырыптары бойынша',
      missed: 'Ұпай қай жерде жоғалды', noMissed: 'Қате жоқ — барлық жауап дұрыс',
      missedNote: 'Бұл пән бойынша тақырыптық талдау әзірге жоқ: сұрақтарға тақырып қойылмаған. Талдауда мұғалім осы сұрақтарды баламен бірге қарайды.',
      ok: 'Тақырып меңгерілген', mid: 'Қайталауды қажет етеді', gap: 'Олқылық',
      cta: 'Талдауға жазылу', ctaNote: 'Мұғалім олқылықтың себебін түсіндіріп, 3 айға жоспар береді.',
      saving: 'Нәтиже сақталуда…', saved: 'Нәтиже сақталды',
      notReady: 'Бұл тест әзірленуде', notReadyNote: 'Дұрыс жауаптар әлі толтырылмаған — нәтижені санау мүмкін емес. Бізге жазыңыз, тестті қолмен таңдаймыз.',
      loadErr: 'Тестті жүктеу мүмкін болмады', again: 'Бетті жаңарту',
      resume: 'Мына сұрақтан жалғастыру', restart: 'Қайтадан бастау'
    }
  };

  /* ---------- 3. СЛУЖЕБНОЕ ---------- */
  var qs = new URLSearchParams(location.search);
  var lang = (qs.get('lang') || (/-kz\/?$/.test(location.pathname) ? 'kz' : 'ru')) === 'kz' ? 'kz' : 'ru';
  var t = T[lang];
  var root = document.getElementById('zd-test');
  if (!root) return;

  var state = { test: null, answers: {}, i: 0, student: null };
  var KEY = 'zd-test-';

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function el(html) { root.innerHTML = html; window.scrollTo({ top: 0, behavior: 'smooth' }); }
  function save() {
    try { localStorage.setItem(KEY + state.test.id, JSON.stringify({ a: state.answers, i: state.i, s: state.student })); } catch (e) {}
  }
  function load(id) {
    try { return JSON.parse(localStorage.getItem(KEY + id) || 'null'); } catch (e) { return null; }
  }
  function clear(id) { try { localStorage.removeItem(KEY + id); } catch (e) {} }

  function getJSON(url) {
    return fetch(url, { cache: 'no-cache' }).then(function (r) {
      if (!r.ok) throw new Error(r.status);
      return r.json();
    });
  }

  /* ---------- 4. ВЫБОР ТЕСТА ---------- */
  function screenPick(manifest, grade) {
    var list = manifest.tests.filter(function (x) { return !grade || x.grade === grade; });
    if (!list.length) list = manifest.tests;
    if (list.length === 1) return openTest(list[0].id);

    el('<div class="zd-card">' +
      '<h1 class="zd-h1">' + esc(t.pickTest) + '</h1>' +
      '<p class="zd-sub">' + esc(t.pickHint) + '</p>' +
      '<div class="zd-list">' + list.map(function (x) {
        return '<button class="zd-pick" data-id="' + esc(x.id) + '">' +
          '<span class="zd-pick-name">' + esc(x.subject[lang]) + '</span>' +
          '<span class="zd-pick-meta">' + x.grade + (lang === 'kz' ? '-сынып' : ' класс') +
          ' · ' + x.questions + (lang === 'kz' ? ' сұрақ' : ' вопросов') +
          ' · ~' + x.minutes + ' мин</span>' +
          (x.ready ? '' : '<span class="zd-tag">' + esc(t.notReady) + '</span>') +
          '</button>';
      }).join('') + '</div></div>');

    root.querySelectorAll('.zd-pick').forEach(function (b) {
      b.addEventListener('click', function () { openTest(b.dataset.id); });
    });
  }

  function openTest(id) {
    el('<div class="zd-card zd-center"><div class="zd-spin"></div></div>');
    getJSON(CONFIG.base + id + '.json').then(function (data) {
      // вопросы с пометкой needsReview не показываем: у них потеряна формула,
      // подчёркивание или рисунок — ответить на них честно нельзя
      data.questions = data.questions.filter(function (q) { return !q.needsReview; });
      state.test = data;
      var kept = load(id);
      if (kept && kept.s) {
        state.answers = kept.a || {}; state.i = kept.i || 0; state.student = kept.s;
        return screenResume();
      }
      screenStart();
    }).catch(function () {
      el('<div class="zd-card"><h1 class="zd-h1">' + esc(t.loadErr) + '</h1>' +
        '<button class="zd-btn" onclick="location.reload()">' + esc(t.again) + '</button></div>');
    });
  }

  /* ---------- 5. СТАРТ ---------- */
  function head() {
    var d = state.test;
    return '<div class="zd-head"><span class="zd-badge">' + d.grade +
      (lang === 'kz' ? '-сынып' : ' класс') + '</span> ' + esc(d.subject[lang]) + '</div>';
  }

  function screenResume() {
    el('<div class="zd-card">' + head() +
      '<h1 class="zd-h1">' + esc(state.student.name) + '</h1>' +
      '<p class="zd-sub">' + esc(t.resume) + ' ' + (state.i + 1) + '</p>' +
      '<button class="zd-btn" id="go">' + esc(t.next) + '</button>' +
      '<button class="zd-btn zd-ghost" id="re">' + esc(t.restart) + '</button></div>');
    root.querySelector('#go').onclick = screenQuestion;
    root.querySelector('#re').onclick = function () {
      clear(state.test.id); state.answers = {}; state.i = 0; screenStart();
    };
  }

  function screenStart() {
    var d = state.test;
    el('<div class="zd-card">' + head() +
      '<h1 class="zd-h1">' + esc(d.subject[lang]) + '</h1>' +
      '<p class="zd-sub">' + d.questions.length + (lang === 'kz' ? ' сұрақ' : ' вопросов') +
      ' · ~' + d.minutes + ' мин</p>' +
      (d.answersFilled ? '' : '<div class="zd-warn"><b>' + esc(t.notReady) + '</b><br>' + esc(t.notReadyNote) + '</div>') +
      '<div class="zd-field"><label for="zd-name">' + esc(t.name) + '</label>' +
      '<input id="zd-name" autocomplete="name" placeholder="' + esc(t.namePh) + '">' +
      '<span class="zd-err" id="zd-name-e">' + esc(t.errName) + '</span></div>' +
      '<div class="zd-field"><label for="zd-phone">' + esc(t.phone) + '</label>' +
      '<input id="zd-phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__">' +
      '<span class="zd-err" id="zd-phone-e">' + esc(t.errPhone) + '</span></div>' +
      '<button class="zd-btn" id="zd-go">' + esc(t.start) + '</button></div>');

    var ph = root.querySelector('#zd-phone');
    ph.addEventListener('input', function () {
      var v = ph.value.replace(/\D/g, '');
      if (v[0] === '8') v = '7' + v.slice(1);
      if (v[0] !== '7') v = '7' + v;
      v = v.slice(0, 11);
      var o = '+7';
      if (v.length > 1) o += ' (' + v.slice(1, 4);
      if (v.length >= 4) o += ')';
      if (v.length > 4) o += ' ' + v.slice(4, 7);
      if (v.length > 7) o += '-' + v.slice(7, 9);
      if (v.length > 9) o += '-' + v.slice(9, 11);
      ph.value = o;
    });
    ph.addEventListener('focus', function () { if (!ph.value) ph.value = '+7 ('; });

    root.querySelector('#zd-go').onclick = function () {
      var nm = root.querySelector('#zd-name').value.trim();
      var digits = ph.value.replace(/\D/g, '');
      var ok = true;
      root.querySelector('#zd-name-e').style.display = nm.length < 2 ? 'block' : 'none';
      root.querySelector('#zd-phone-e').style.display = digits.length !== 11 ? 'block' : 'none';
      if (nm.length < 2 || digits.length !== 11) ok = false;
      if (!ok) return;
      state.student = { name: nm, phone: '+' + digits };
      state.i = 0; state.answers = {};
      save(); screenQuestion();
    };
  }

  /* ---------- 6. ВОПРОСЫ ---------- */
  function screenQuestion() {
    var d = state.test, q = d.questions[state.i], total = d.questions.length;
    var picked = state.answers[q.n];
    var pct = Math.round(state.i / total * 100);

    el('<div class="zd-card">' +
      '<div class="zd-bar"><span style="width:' + pct + '%"></span></div>' +
      '<div class="zd-qmeta">' + esc(t.q) + ' ' + (state.i + 1) + ' ' + esc(t.of) + ' ' + total +
      (q.topic ? '<span class="zd-topic">' + esc(q.topic) + '</span>' : '') + '</div>' +
      (q.passage ? '<div class="zd-passage">' + esc(q.passage) + '</div>' : '') +
      // blockImage — вопрос вместе с вариантами снят картинкой из исходника
      // (формулы и дроби, которые нельзя перенести текстом)
      (q.blockImage
        ? [].concat(q.blockImage).map(function (src) {
            return '<img class="zd-img zd-block" src="' + esc(CONFIG.base + src) + '" alt="">';
          }).join('')
        : '<div class="zd-qtext">' + esc(q.text) + '</div>' +
          (q.image ? '<img class="zd-img" src="' + esc(CONFIG.base + q.image) + '" alt="">' : '')) +
      '<div class="zd-opts' + (q.optionImages ? ' zd-opts-img' : '') +
      (q.blockImage ? ' zd-opts-letters' : '') + '">' +
      (q.optionImages || q.options).map(function (o, k) {
        var body = q.optionImages
          ? '<img src="' + esc(CONFIG.base + o) + '" alt="">'
          : '<span>' + esc(o) + '</span>';
        return '<button class="zd-opt' + (picked === k ? ' on' : '') + '" data-k="' + k + '">' +
          '<i>' + String.fromCharCode(65 + k) + '</i>' + body + '</button>';
      }).join('') + '</div>' +
      '<div class="zd-nav">' +
      (state.i > 0 ? '<button class="zd-btn zd-ghost" id="zd-prev">' + esc(t.prev) + '</button>' : '') +
      '<button class="zd-btn" id="zd-next">' +
      esc(state.i === total - 1 ? t.finish : t.next) + '</button></div>' +
      '<div class="zd-hint" id="zd-hint"></div></div>');

    root.querySelectorAll('.zd-opt').forEach(function (b) {
      b.onclick = function () {
        state.answers[q.n] = Number(b.dataset.k);
        root.querySelectorAll('.zd-opt').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        root.querySelector('#zd-hint').textContent = '';
        save();
      };
    });
    var prev = root.querySelector('#zd-prev');
    if (prev) prev.onclick = function () { state.i--; save(); screenQuestion(); };
    root.querySelector('#zd-next').onclick = function () {
      if (state.answers[q.n] === undefined) {
        root.querySelector('#zd-hint').textContent = t.pickAnswer;
        return;
      }
      if (state.i === total - 1) return finish();
      state.i++; save(); screenQuestion();
    };
  }

  /* ---------- 7. РЕЗУЛЬТАТ ---------- */
  function grade(pct) { return pct >= 70 ? 'ok' : pct >= 45 ? 'mid' : 'gap'; }

  function finish() {
    var d = state.test, rows = [], right = 0, scored = 0;
    var byTopic = {}, missed = [];
    // темы проставлены не у всех тестов; без них сорок полосок по одному вопросу —
    // не отчёт, поэтому показываем просто номера, где потеряны баллы
    var hasTopics = d.questions.some(function (q) { return q.topic; });

    d.questions.forEach(function (q) {
      var a = state.answers[q.n];
      if (q.correct === null || q.correct === undefined) return;
      scored++;
      var hit = a === q.correct;
      if (hit) right++; else missed.push(q.n);
      if (!hasTopics) return;
      var key = q.topic || (lang === 'kz' ? 'Басқа' : 'Прочее');
      byTopic[key] = byTopic[key] || { right: 0, total: 0 };
      byTopic[key].total++;
      if (hit) byTopic[key].right++;
    });

    Object.keys(byTopic).forEach(function (k) {
      var v = byTopic[k], pct = Math.round(v.right / v.total * 100);
      rows.push({ name: k, pct: pct, right: v.right, total: v.total, s: grade(pct) });
    });
    rows.sort(function (a, b) { return a.pct - b.pct; });

    var overall = scored ? Math.round(right / scored * 100) : null;
    var wa = 'https://wa.me/' + CONFIG.whatsapp + '?text=' +
      encodeURIComponent((lang === 'kz' ? 'Сәлеметсіз бе! ' : 'Здравствуйте! ') +
        state.student.name + ' — ' + d.subject.ru + ', ' + d.grade +
        (lang === 'kz' ? '-сынып' : ' класс') +
        (overall === null ? '' : ', ' + overall + '%'));

    el('<div class="zd-card">' + head() +
      '<h1 class="zd-h1">' + esc(t.resultTitle) + '</h1>' +
      '<p class="zd-sub">' + esc(state.student.name) + '</p>' +
      (overall === null
        ? '<div class="zd-warn"><b>' + esc(t.notReady) + '</b><br>' + esc(t.notReadyNote) + '</div>'
        : '<div class="zd-score"><b>' + overall + '%</b><span>' + esc(t.score) + ': ' +
          right + ' / ' + scored + '</span></div>' +
          (hasTopics
            ? '<div class="zd-sec">' + esc(t.byTopic) + '</div>' +
              '<div class="zd-rows">' + rows.map(function (r) {
                return '<div class="zd-row"><div class="zd-row-h"><span>' + esc(r.name) + '</span>' +
                  '<b>' + r.pct + '%</b></div><div class="zd-track"><i class="' + r.s +
                  '" style="width:' + r.pct + '%"></i></div></div>';
              }).join('') + '</div>' +
              '<div class="zd-legend">' +
              '<span><i class="ok"></i>' + esc(t.ok) + '</span>' +
              '<span><i class="mid"></i>' + esc(t.mid) + '</span>' +
              '<span><i class="gap"></i>' + esc(t.gap) + '</span></div>'
            : '<div class="zd-sec">' + esc(missed.length ? t.missed : t.noMissed) + '</div>' +
              (missed.length
                ? '<div class="zd-chips">' + missed.map(function (n) {
                    return '<span>№' + n + '</span>';
                  }).join('') + '</div>' +
                  '<p class="zd-sub" style="margin-top:12px">' + esc(t.missedNote) + '</p>'
                : ''))) +
      '<p class="zd-sub" style="margin-top:18px">' + esc(t.ctaNote) + '</p>' +
      '<a class="zd-btn" href="' + wa + '" target="_blank" rel="noopener">' + esc(t.cta) + '</a>' +
      '<div class="zd-hint" id="zd-save">' + esc(t.saving) + '</div></div>');

    clear(d.id);
    send({
      date: new Date().toISOString(),
      name: state.student.name,
      phone: state.student.phone,
      grade: d.grade,
      subject: d.subject.ru,
      testId: d.id,
      right: right,
      scored: scored,
      percent: overall,
      topics: rows.map(function (r) { return r.name + ': ' + r.pct + '%'; }).join('; '),
      answers: d.questions.map(function (q) { return q.n + '=' + (state.answers[q.n] === undefined ? '-' : state.answers[q.n]); }).join(','),
      lang: lang,
      page: location.pathname
    });
  }

  function send(payload) {
    var box = root.querySelector('#zd-save');
    if (!CONFIG.endpoint) { if (box) box.textContent = ''; console.log('Результат (endpoint не настроен):', payload); return; }
    fetch(CONFIG.endpoint, {
      method: 'POST', mode: 'no-cors',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payload)
    }).then(function () { if (box) box.textContent = t.saved; })
      .catch(function () { if (box) box.textContent = ''; });
  }

  /* ---------- 8. СТАРТ ПРИЛОЖЕНИЯ ---------- */
  var wantTest = qs.get('test');
  var wantGrade = parseInt(qs.get('class') || qs.get('grade'), 10) || null;

  el('<div class="zd-card zd-center"><div class="zd-spin"></div></div>');
  if (wantTest) {
    openTest(wantTest);
  } else {
    getJSON(CONFIG.base + 'manifest.json')
      .then(function (m) { screenPick(m, wantGrade); })
      .catch(function () {
        el('<div class="zd-card"><h1 class="zd-h1">' + esc(t.loadErr) + '</h1>' +
          '<button class="zd-btn" onclick="location.reload()">' + esc(t.again) + '</button></div>');
      });
  }
})();
